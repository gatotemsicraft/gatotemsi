# 🎣 Mancing Mabar

Game mancing pixel 2D multiplayer. Jalan bareng teman di "dermaga" yang sama,
lihat karakter mereka gerak real-time, mancing bareng, dan pakai skin
pixel 16×16 buatan sendiri yang otomatis kelihatan oleh pemain lain.

Dibuat dengan: **Phaser 3** (game engine, via CDN) + **Socket.IO** (realtime) +
**Node.js/Express** (server) — semuanya gratis untuk di-host.

```
fishing-game/
├── server/           # Node.js + Socket.IO (source of truth multiplayer)
│   ├── index.js
│   └── package.json
├── client/           # Static site (HTML/CSS/JS), disajikan oleh server
│   ├── index.html
│   ├── style.css
│   ├── skinEditor.js
│   └── game.js
└── README.md
```

## Fitur

- Gerak multiplayer real-time (WASD / panah).
- Beberapa titik mancing (lingkaran hijau) — dekati lalu tekan **SPASI**,
  tunggu gigitan, lalu tekan SPASI lagi di waktu yang tepat buat dapat ikan.
- Editor skin 16×16 piksel: gambar sendiri, otomatis tersinkron ke semua
  pemain lain di dermaga yang sama.
- Papan skor & obrolan (chat) dermaga.
- Sistem "room" (kode dermaga) — pakai kode yang sama dengan teman biar
  ketemu di kolam yang sama. Beda kode = beda sesi/instance.

## Menjalankan di komputer sendiri

Butuh [Node.js](https://nodejs.org) versi 18+.

```bash
cd server
npm install
npm start
```

Server jalan di `http://localhost:3000` — server ini juga otomatis
menyajikan file client, jadi tinggal buka URL itu di browser. Buka di
2 tab/browser berbeda (atau kirim ke teman lewat tunnel seperti ngrok)
untuk tes multiplayer.

## Push ke GitHub

```bash
cd fishing-game
git init
git add .
git commit -m "Mancing Mabar: initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git push -u origin main
```

## Deploy gratis (biar teman-teman bisa main tanpa kamu nyalain laptop)

Karena game ini butuh **WebSocket real-time**, GitHub Pages **tidak bisa**
dipakai sendirian (GitHub Pages cuma hosting file statis, tidak bisa
menjalankan server Node.js/Socket.IO). Solusi termudah & gratis:

### Opsi A — Render.com (paling simpel, 1 service untuk semua)
1. Push repo ini ke GitHub (lihat di atas).
2. Buka [render.com](https://render.com) → New → **Web Service** → hubungkan
   repo GitHub kamu.
3. Isi konfigurasi:
   - **Root Directory**: `server`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free
4. Deploy. Render kasih URL publik (`https://nama-app.onrender.com`) —
   itu link yang kamu share ke teman untuk main bareng.
5. Catatan: di plan gratis, server "tidur" kalau tidak dipakai 15 menit dan
   butuh ~30-60 detik untuk bangun lagi saat diakses pertama kali.

### Opsi B — Railway / Fly.io / Glitch
Caranya mirip: hubungkan repo, root directory `server`, start command
`npm start`. Semuanya punya free tier.

### Kalau tetap mau pakai GitHub Pages
GitHub Pages bisa dipakai untuk **client saja** (folder `client/`), tapi
kamu tetap butuh server terpisah (Render/Railway) untuk bagian
Socket.IO-nya. Kalau begitu, di `game.js` ganti baris:
```js
socket = io();
```
menjadi:
```js
socket = io("https://nama-app.onrender.com");
```
supaya client (di GitHub Pages) connect ke server (di Render).

## Ide pengembangan lanjutan

- **Anti-cheat**: saat ini hasil tangkapan ikan dipercaya dari client
  (`points` dikirim client). Untuk versi lebih serius, pindahkan logika
  random ikan + validasi jarak ke titik mancing sepenuhnya ke server.
- **Persistensi**: skor & skin sekarang hanya di memori server (hilang
  kalau server restart). Bisa disambungkan ke database gratis seperti
  Supabase/MongoDB Atlas kalau mau permanen.
- **Room list / matchmaking**: sekarang room hanya berdasarkan kode teks
  yang diketik manual. Bisa ditambah UI daftar room aktif.
- **Asset pixel art asli**: dunia game sekarang digambar dengan bentuk
  sederhana (kotak/lingkaran) lewat kode, belum pakai tileset pixel art
  beneran. Bisa diganti dengan tileset (mis. dari itch.io yang berlisensi
  gratis) + Tiled map editor untuk hasil yang lebih detail.
- **Mobile controls**: tambahkan tombol virtual joystick untuk main dari HP.
